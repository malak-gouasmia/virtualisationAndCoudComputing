import sys
import libvirt

CONNECTION_PATH = "qemu:///system"
MENU_TEXT = """\


1) Start a VM
2) Stop a VM
3) List all VMs
4) Show info about a VM
5) Show info about the hypervisor
0) Exit
"""

class Controller(object):
    STATE_ACTIVE = 2**0
    STATE_INACTIVE = 2**1
    STATE_ALL = STATE_ACTIVE | STATE_INACTIVE

    # Initialization method
    def __init__(self, conn_path):
        try:
            self.conn = libvirt.open(conn_path)
        except libvirt.libvirtError, e:
            print >>sys.stderr, "Cannot open connection to '{}' : {}".format(conn_path, repr(e))
            sys.exit(1)

        self.update_domains()
        self.funcs = {
            1: self.start_vm,
            2: self.stop_vm,
            3: self.list_vm_all,
            4: self.info_vm,
            5: self.info_hypervisor,
            0: self.exit,
        }

    # Update list of active and inactive VMs
    def update_domains(self):
        self.inactive_vms = self.conn.listDefinedDomains()
        if self.inactive_vms == None:
            print >>sys.stderr, 'Failed to get a list of inactive VMs'
            sys.exit(1)
        self.active_vms = self.conn.listDomainsID()
        if self.active_vms == None:
            print >>sys.stderr, 'Failed to get a list of active VMs'
            sys.exit(1)

    def exec_funcs(self, num):
        assert(num in self.funcs)
        self.update_domains()
        return self.funcs[num]()

    def list_vm_active(self):
        self.list_vm(Controller.STATE_ACTIVE)

    def list_vm_inactive(self):
        self.list_vm(Controller.STATE_INACTIVE)

    def list_vm_all(self):
        self.list_vm(Controller.STATE_ALL)

    # Choose active VM by ID
    def choose_by_id(self):
        choice = None
        dom = None
        while choice == None or dom == None:
            try:
                choice = int(raw_input("Choose VM ID : "))
            except ValueError:
                print >>sys.stderr, "Error : ID needs to be a valid integer"
                continue
            try:
                dom = self.conn.lookupByID(choice)
            except libvirt.libvirtError, e:
                print >>sys.stderr, "Failed to find active VM with ID '{}' : {}".format(choice, repr(e))
        return dom

    # Choose VM by name
    def choose_by_name(self):
        dom = None
        while dom == None:
            name = raw_input("Enter VM name : ")
            try:
                dom = self.conn.lookupByName(name)
            except libvirt.libvirtError, e:
                print >>sys.stderr, "Failed to find VM with name : '{}'".format(name)
        return dom

    # List VMs based on flag (ACTIVE, INACTIVE, ALL)
    def list_vm(self, flag):
        # Header
        i1 = 10
        i2 = 50
        i3 = 5
        fmt = "{{:{}}} {{:{}}} {{:{}}}".format(i1, i2, i3)
        sep = "-"*(i1+i2+i3+3)
        print sep
        print fmt.format('ID', 'Name', 'Powered')
        print sep
	# List VMs
        if flag & Controller.STATE_ACTIVE:
            for domain_id in self.active_vms:
                print fmt.format(str(domain_id), self.conn.lookupByID(domain_id).name(), 'ON')
        if flag & Controller.STATE_INACTIVE:
            for domain_name in self.inactive_vms:
                print fmt.format("-", domain_name, 'OFF')

    # Start VM
    def start_vm(self):
        self.list_vm_inactive()
        dom = self.choose_by_name()
        if dom.create() < 0:
            print >>sys.stderr, "Can not start VM '{}'".format(dom.name())
        else:
            print "VM '{}' has started".format(dom.name())

    # Stop VM
    def stop_vm(self):
        self.list_vm_active()
        dom = self.choose_by_name()
        dom.destroy()
        print "VM '{}' has been stopped".format(dom.name())

    # Show VM information
    def info_vm(self):
        domain = self.choose_by_name()
        try:
            print 'Domain information :'
            print 'Powered : {}'.format('ON' if domain.isActive() else 'OFF')
            print 'Name : {}'.format(domain.name())
            print 'ID : {}'.format('-' if domain.ID()==-1 else domain.ID())
            print 'UUID : {}'.format(domain.UUIDString())
            print 'Operating system type : {}'.format(domain.OSType())
            print 'Maximum memory allocated in MB: {}'.format(domain.maxMemory()/1024)
            if domain.isActive():
                print 'Maximum number of virtual cpus allocated : {}'.format(domain.maxVcpus())
        except libvirt.libvirtError, e:
            print >>sys.stderr, "Cannot get domain information : {}".format(repr(e))
            sys.exit(1)

    # Show hypervisor information
    def info_hypervisor(self):
        try:
            nodeinfo = self.conn.getInfo()
            print 'Hyperisor information :'
            print 'Hostname : {}'.format(self.conn.getHostname())
            print 'CPU model : {}'.format(nodeinfo[0])
            print 'Memory size in MB : {}'.format(nodeinfo[1])
            print 'Number of CPUs : {}'.format(nodeinfo[2])
            print 'Number of CPU sockets : {}'.format(nodeinfo[5])
            print 'Number of CPU cores per socket : {}'.format(nodeinfo[6])
            print 'Number of CPU threads per core : {}'.format(nodeinfo[7])
        except libvirt.libvirtError, e:
            print >>sys.stderr, "Cannot get hypervisor information : {}".format(repr(e))
            sys.exit(1)

    # Close connection
    def close(self):
        return self.conn.close()

    # Exit
    def exit(self):
        self.close()
        sys.exit(0)

def main():
    ctrl = Controller(CONNECTION_PATH)

    while True:
        print MENU_TEXT
        try:
            choice = int(raw_input("Choice : "))
        except ValueError:
            print >>sys.stderr, "Error : Choice needs to be a valid integer"
            continue
        ctrl.exec_funcs(choice)

if __name__ == "__main__":
    main()
